	package examples;
	
	public class Application {
	
		public static void main(String[] args) {
			//COMMENTS MUHA HA HA
			System.out.println("Hello, World");
			System.out.println("this is another string literal. MUAHAHAHA");
	
			System.out.print("helllllllo");
			System.out.print("! "+"hello" + ", " + "world!");
		}
	
	}
